' Runs on a background thread: fetches a URL and turns the response into a list of entries.
' mode = "list" -> parse as JSON or an HTML directory listing
' mode = "raw"  -> return the body as plain text

sub init()
    m.top.functionName = "fetchData"
end sub

sub fetchData()
    url = m.top.url
    mode = m.top.mode
    result = { ok: false, mode: mode, url: url, code: 0, error: "", entries: [], text: "", body: "" }

    port = CreateObject("roMessagePort")
    req = CreateObject("roUrlTransfer")
    req.SetMessagePort(port)
    req.SetUrl(url)
    req.EnableEncodings(true)
    req.RetainBodyOnError(true)
    if LCase(Left(url, 5)) = "https" then
        req.SetCertificatesFile("common:/certs/ca-bundle.crt")
        req.InitClientCertificates()
    end if

    if not req.AsyncGetToString() then
        result.error = "Couldn't start request (check the address)"
        m.top.result = result
        return
    end if

    msg = Wait(10000, port)
    if msg = invalid then
        req.AsyncCancel()
        result.error = "Timed out after 10 seconds"
    else if Type(msg) = "roUrlEvent" then
        result.code = msg.GetResponseCode()
        if result.code >= 200 and result.code < 300 then
            body = msg.GetString()
            result.ok = true
            if mode = "raw" then
                result.body = clip(body)
            else
                parsed = parseListing(body, url)
                result.entries = parsed.entries
                result.text = clip(parsed.text)
            end if
        else
            result.error = msg.GetFailureReason()
            if result.error = "" then result.error = "HTTP " + result.code.ToStr()
        end if
    end if

    m.top.result = result
end sub

function clip(s as string) as string
    if Len(s) > 100000 then return Left(s, 100000) + Chr(10) + "... (truncated)"
    return s
end function

function parseListing(body as string, baseUrl as string) as object
    out = { entries: [], text: "" }
    trimmed = body.Trim()
    if trimmed = "" then return out

    first = Left(trimmed, 1)
    if first = "[" or first = "{" then
        json = ParseJson(trimmed)
        if json <> invalid then
            out.entries = entriesFromJson(json, baseUrl)
            return out
        end if
    end if

    if Instr(1, LCase(trimmed), "<a ") > 0 then
        out.entries = entriesFromHtml(trimmed, baseUrl)
        if out.entries.Count() > 0 then return out
    end if

    out.text = body
    return out
end function

' ---------- JSON ----------
' Accepts an array, or an object containing an array under items/files/videos/results/data/entries.
' Each item can be a string (path/url) or an object with title/name + url/path/stream/src etc.
function entriesFromJson(json as dynamic, baseUrl as string) as object
    entries = []
    origin = originOf(baseUrl)
    baseDir = dirOf(baseUrl)
    list = invalid

    if Type(json) = "roArray" then
        list = json
    else if Type(json) = "roAssociativeArray" then
        for each key in ["items", "files", "videos", "results", "data", "entries"]
            v = json[key]
            if v <> invalid and Type(v) = "roArray" then
                list = v
                exit for
            end if
        end for
        if list = invalid then
            ' No list in there: show the key/value pairs as read-only lines
            for each key in json
                entries.Push({ title: key + ": " + toText(json[key]), kind: "info", url: "", thumb: "", desc: "" })
            end for
            return entries
        end if
    end if
    if list = invalid then return entries

    for each item in list
        t = Type(item)
        if t = "roString" or t = "String" then
            url = resolveUrl(item, origin, baseDir)
            entries.Push({ title: decodeName(lastSegment(url)), kind: kindFor(url, true), url: url, thumb: "", desc: "" })
        else if t = "roAssociativeArray" then
            link = firstStr(item, ["url", "stream", "src", "path", "href", "link", "file"])
            title = firstStr(item, ["title", "name", "filename", "label", "file"])
            thumb = firstStr(item, ["thumbnail", "thumb", "image", "poster", "cover"])
            desc = firstStr(item, ["description", "desc", "summary"])
            typ = LCase(firstStr(item, ["type", "kind"]))
            if thumb <> "" then thumb = resolveUrl(thumb, origin, baseDir)

            if link <> "" then
                url = resolveUrl(link, origin, baseDir)
                kind = kindFromType(typ)
                if kind = "" then kind = kindFor(url, true)
                if title = "" then title = decodeName(lastSegment(url))
                entries.Push({ title: title, kind: kind, url: url, thumb: thumb, desc: desc })
            else
                if title = "" then title = FormatJson(item)
                entries.Push({ title: title, kind: "info", url: "", thumb: thumb, desc: desc })
            end if
        else
            entries.Push({ title: toText(item), kind: "info", url: "", thumb: "", desc: "" })
        end if
    end for
    return entries
end function

' ---------- HTML directory listings (python -m http.server, nginx autoindex, Apache, etc.) ----------
function entriesFromHtml(html as string, baseUrl as string) as object
    dirs = []
    files = []
    seen = {}
    origin = originOf(baseUrl)
    baseDir = dirOf(baseUrl)
    re = CreateObject("roRegex", "href\s*=\s*[""']([^""']+)[""']", "i")

    for each hit in re.MatchAll(html)
        href = hit[1]
        lower = LCase(href)
        skip = false
        if href = "" or Left(href, 1) = "#" or Left(href, 1) = "?" then skip = true
        if Left(lower, 7) = "mailto:" or Left(lower, 11) = "javascript:" then skip = true
        if href = "../" or href = ".." or href = "./" or href = "/" then skip = true

        if not skip then
            url = resolveUrl(href, origin, baseDir)
            if LCase(Left(url, Len(origin))) <> LCase(origin) then skip = true          ' external link
            if LCase(Left(baseDir, Len(url))) = LCase(url) then skip = true             ' parent / self link
            if seen.DoesExist(url) then skip = true
        end if

        if not skip then
            seen[url] = true
            name = url
            if Right(name, 1) = "/" then name = Left(name, Len(name) - 1)
            name = decodeName(lastSegment(name))
            kind = kindFor(url, false)
            entry = { title: name, kind: kind, url: url, thumb: "", desc: "" }
            if kind = "dir" then
                entry.title = name + "/"
                dirs.Push(entry)
            else
                files.Push(entry)
            end if
        end if
    end for

    for each f in files
        dirs.Push(f)
    end for
    return dirs
end function

' ---------- helpers ----------
function kindFromType(t as string) as string
    if t = "folder" or t = "dir" or t = "directory" or t = "list" or t = "collection" then return "dir"
    if t = "audio" or t = "music" or t = "song" or t = "track" then return "audio"
    if t = "video" or t = "movie" or t = "episode" or t = "stream" then return "video"
    if t = "image" or t = "photo" or t = "picture" then return "image"
    if t = "text" or t = "note" then return "text"
    return ""
end function

' Decide what an entry is from its URL. unknownIsDir=true is used for JSON, where an
' extension-less link is most likely another API endpoint to browse into.
function kindFor(url as string, unknownIsDir as boolean) as string
    n = LCase(url)
    q = Instr(1, n, "?")
    if q > 0 then n = Left(n, q - 1)
    if Right(n, 1) = "/" then return "dir"

    ext = ""
    i = Len(n)
    while i > 0
        c = Mid(n, i, 1)
        if c = "." then
            ext = Mid(n, i + 1)
            exit while
        else if c = "/" then
            exit while
        end if
        i = i - 1
    end while

    if ext = "" then
        if unknownIsDir then return "dir"
        return "file"
    end if

    padded = " " + ext + " "
    if Instr(1, " mp4 m4v mov mkv webm m3u8 mpd ", padded) > 0 then return "video"
    if Instr(1, " mp3 wav flac m4a aac ogg oga opus aiff aif wma ", padded) > 0 then return "audio"
    if Instr(1, " jpg jpeg png gif bmp ", padded) > 0 then return "image"
    if Instr(1, " txt md log csv tsv srt vtt lrc nfo ini cfg conf yml yaml xml ", padded) > 0 then return "text"
    if Instr(1, " json html htm ", padded) > 0 then return "dir"
    return "file"
end function

function firstStr(item as object, keys as object) as string
    for each k in keys
        v = item[k]
        if v <> invalid then
            t = Type(v)
            if (t = "roString" or t = "String") and v <> "" then return v
        end if
    end for
    return ""
end function

function toText(v as dynamic) as string
    t = Type(v)
    if t = "roString" or t = "String" then return v
    return FormatJson(v)
end function

function decodeName(s as string) as string
    return CreateObject("roUrlTransfer").Unescape(s)
end function

function lastSegment(s as string) as string
    i = Len(s)
    while i > 0
        if Mid(s, i, 1) = "/" then return Mid(s, i + 1)
        i = i - 1
    end while
    return s
end function

function originOf(u as string) as string
    p = Instr(1, u, "://")
    if p = 0 then return u
    s = Instr(p + 3, u, "/")
    if s = 0 then return u
    return Left(u, s - 1)
end function

function dirOf(u as string) as string
    q = Instr(1, u, "?")
    if q > 0 then u = Left(u, q - 1)
    i = Len(u)
    while i > 7 and Mid(u, i, 1) <> "/"
        i = i - 1
    end while
    if i <= 7 then return u + "/"
    return Left(u, i)
end function

function resolveUrl(href as string, origin as string, baseDir as string) as string
    l = LCase(href)
    if Left(l, 7) = "http://" or Left(l, 8) = "https://" then return href
    if Left(href, 2) = "//" then return "http:" + href
    if Left(href, 1) = "/" then return origin + href
    if Left(href, 2) = "./" then href = Mid(href, 3)
    return baseDir + href
end function
