' Local Fetcher - main scene

sub init()
    ' Used only the first time, before a server has been saved. You can change it from the app (press *).
    m.DEFAULT_SERVER = "http://192.168.1.100:8000/"
    m.BAR_WIDTH = 620

    m.status = m.top.findNode("status")
    m.list = m.top.findNode("list")
    m.preview = m.top.findNode("preview")
    m.details = m.top.findNode("details")
    m.nowPlaying = m.top.findNode("nowPlaying")
    m.video = m.top.findNode("video")
    m.imageGroup = m.top.findNode("imageGroup")
    m.imagePoster = m.top.findNode("imagePoster")
    m.imageCaption = m.top.findNode("imageCaption")
    m.slideTimer = m.top.findNode("slideTimer")
    m.audioWatchdog = m.top.findNode("audioWatchdog")
    m.textGroup = m.top.findNode("textGroup")
    m.textTitle = m.top.findNode("textTitle")
    m.textArea = m.top.findNode("textArea")
    m.npGroup = m.top.findNode("npGroup")
    m.npArt = m.top.findNode("npArt")
    m.npTitle = m.top.findNode("npTitle")
    m.npTrack = m.top.findNode("npTrack")
    m.npState = m.top.findNode("npState")
    m.npFill = m.top.findNode("npFill")
    m.npTime = m.top.findNode("npTime")

    m.reg = CreateObject("roRegistrySection", "localfetcher")
    m.server = m.DEFAULT_SERVER
    if m.reg.Exists("server") then m.server = m.reg.Read("server")

    m.stack = []            ' folders we came from: { url, idx }
    m.entries = []
    m.currentUrl = ""
    m.pendingUrl = ""
    m.pendingNav = "none"   ' "push" (into a folder), "pop" (back up), "refresh", or "none"
    m.pendingIdx = 0
    m.restoreIndex = 0

    m.audioQueue = []
    m.audioIndex = 0
    m.audioActive = false
    m.audioCover = ""
    m.imageQueue = []
    m.imageIndex = 0
    m.slideshow = false

    ' Music can be played by two different Roku players; the app tries them in turn (see "music" below)
    m.audioVideo = m.top.findNode("audioVideo")
    m.audioVideo.enableUI = false
    m.audioVideo.observeField("state", "onAudioVideoState")
    m.audioVideo.observeField("position", "onAudioVideoPosition")
    m.audioPlayer = CreateObject("roSGNode", "Audio")
    m.audioPlayer.observeField("state", "onAudioPlayerState")
    m.audioPlayer.observeField("position", "onAudioPlayerPosition")
    m.audioEngine = "video"
    m.audioAttempt = 0

    m.list.observeField("itemSelected", "onItemSelected")
    m.list.observeField("itemFocused", "onItemFocused")
    m.video.observeField("state", "onVideoState")
    m.slideTimer.observeField("fire", "onSlideTick")
    m.audioWatchdog.observeField("fire", "onAudioWatchdog")

    m.list.setFocus(true)

    ' Small delay so the dialog can be shown on first launch
    m.startTimer = m.top.findNode("startTimer")
    m.startTimer.observeField("fire", "onStart")
    m.startTimer.control = "start"
end sub

sub onStart()
    if m.reg.Exists("server") then
        navigateTo(m.server, "none")
    else
        m.status.text = "Welcome! Enter the address of your local server."
        openServerDialog()
    end if
end sub

' ---------- networking ----------
sub navigateTo(url as string, nav as string)
    m.pendingUrl = url
    m.pendingNav = nav
    m.pendingIdx = 0
    if nav = "push" or nav = "refresh" then
        idx = m.list.itemFocused
        if idx <> invalid then m.pendingIdx = idx
    end if
    m.status.text = "Loading " + url + " ..."
    startTask(url, "list")
end sub

sub startTask(url as string, mode as string)
    m.task = CreateObject("roSGNode", "ApiTask")
    m.task.url = url
    m.task.mode = mode
    m.task.observeField("result", "onApiResult")
    m.task.control = "RUN"
end sub

sub onApiResult(event as object)
    r = event.getData()
    if r = invalid then return

    if not r.ok then
        m.status.text = "Couldn't load " + r.url + " -- " + r.error + "   (press * to change server)"
        return
    end if

    if r.mode = "raw" then
        showText(r.url, r.body)
        return
    end if

    ' Response wasn't JSON or a directory listing: just show it as text
    if r.entries.Count() = 0 and r.text <> "" then
        showText(r.url, r.text)
        return
    end if

    m.restoreIndex = 0
    if m.pendingNav = "push" and m.currentUrl <> "" then
        m.stack.Push({ url: m.currentUrl, idx: m.pendingIdx })
    else if m.pendingNav = "pop" and m.stack.Count() > 0 then
        prev = m.stack.Pop()
        m.restoreIndex = prev.idx
    else if m.pendingNav = "refresh" then
        m.restoreIndex = m.pendingIdx
    end if
    m.currentUrl = r.url
    showEntries(r.entries, r.url)
end sub

' ---------- list ----------
sub showEntries(entries as object, url as string)
    m.entries = entries
    root = CreateObject("roSGNode", "ContentNode")
    for each e in entries
        node = root.CreateChild("ContentNode")
        node.title = tagFor(e.kind) + e.title
    end for
    m.list.content = root
    m.list.setFocus(true)

    m.status.text = url + "   (" + entries.Count().ToStr() + " items)"
    if entries.Count() > 0 then
        idx = m.restoreIndex
        if idx >= entries.Count() then idx = 0
        m.list.jumpToItem = idx
        updatePreview(idx)
    else
        m.preview.uri = ""
        m.details.text = "Nothing here."
    end if
end sub

function tagFor(kind as string) as string
    if kind = "dir" then return "[folder]  "
    if kind = "video" then return "[video]  "
    if kind = "audio" then return "[music]  "
    if kind = "image" then return "[image]  "
    if kind = "text" then return "[text]  "
    if kind = "file" then return "[file]  "
    return ""
end function

sub onItemFocused(event as object)
    updatePreview(event.getData())
end sub

sub updatePreview(idx as integer)
    if idx < 0 or idx >= m.entries.Count() then return
    e = m.entries[idx]

    if e.thumb <> "" then
        m.preview.uri = e.thumb
    else if e.kind = "image" then
        m.preview.uri = e.url
    else if e.kind = "audio" then
        m.preview.uri = findCover()
    else
        m.preview.uri = ""
    end if

    txt = e.title
    if e.desc <> "" then txt = txt + Chr(10) + e.desc
    if e.url <> "" then txt = txt + Chr(10) + e.url
    m.details.text = txt
end sub

' Looks for cover.jpg / folder.jpg / front.png etc. among the current folder's entries
function findCover() as string
    for each e in m.entries
        if e.kind = "image" then
            t = LCase(e.title)
            if Instr(1, t, "cover") > 0 or Instr(1, t, "folder") > 0 or Instr(1, t, "front") > 0 or Instr(1, t, "album") > 0 then return e.url
        end if
    end for
    return ""
end function

sub onItemSelected(event as object)
    idx = event.getData()
    if idx < 0 or idx >= m.entries.Count() then return
    e = m.entries[idx]

    if e.kind = "dir" then
        navigateTo(e.url, "push")
    else if e.kind = "video" then
        playVideo(e)
    else if e.kind = "audio" then
        startAudio(idx)
    else if e.kind = "image" then
        startImages(idx)
    else if e.kind = "text" then
        m.status.text = "Loading " + e.title + " ..."
        startTask(e.url, "raw")
    else if e.kind = "file" then
        m.status.text = "Roku can't open this file type: " + e.title
    end if
end sub

' ---------- video ----------
sub playVideo(e as object)
    if m.audioActive then stopAudio()
    content = CreateObject("roSGNode", "ContentNode")
    content.url = e.url
    content.title = e.title
    fmt = videoFormatFor(e.url)
    if fmt <> "" then content.streamFormat = fmt
    m.video.content = content
    m.video.visible = true
    m.video.setFocus(true)
    m.video.control = "play"
end sub

function videoFormatFor(url as string) as string
    ext = extOf(url)
    if ext = "m3u8" then return "hls"
    if ext = "mpd" then return "dash"
    if ext = "mkv" then return "mkv"
    if ext = "mp4" or ext = "m4v" or ext = "mov" then return "mp4"
    return ""
end function

sub closeVideo()
    m.video.control = "stop"
    m.video.visible = false
    m.list.setFocus(true)
end sub

sub onVideoState(event as object)
    state = event.getData()
    if state = "finished" then
        closeVideo()
    else if state = "error" then
        msg = m.video.errorMsg
        closeVideo()
        m.status.text = "Playback error: " + msg
    end if
end sub

' ---------- music ----------
' Each track is tried in up to three ways until one starts playing:
'   attempt 0 = the Video node (the same player that plays your mp4s)
'   attempt 1 = the Audio node (only for formats it documents: mp3, flac, m4a, aac)
'   attempt 2 = ask the PC server to convert the file to MP3 (needs ffmpeg on the PC)

' Selecting a track queues every music file in the current folder, starting from that one.
sub startAudio(idx as integer)
    m.audioQueue = []
    m.audioIndex = 0
    for i = 0 to m.entries.Count() - 1
        e = m.entries[i]
        if e.kind = "audio" then
            if i = idx then m.audioIndex = m.audioQueue.Count()
            m.audioQueue.Push(e)
        end if
    end for
    m.audioCover = findCover()
    m.audioActive = true
    playTrack()
    showNowPlaying()
end sub

sub playTrack()
    if m.audioQueue.Count() = 0 then return
    e = m.audioQueue[m.audioIndex]
    m.audioAttempt = 0

    m.npTitle.text = e.title
    m.npTrack.text = "Track " + itos(m.audioIndex + 1) + " of " + itos(m.audioQueue.Count())
    m.npState.text = "Buffering..."
    m.npFill.width = 1
    m.npTime.text = "0:00 / 0:00"
    art = e.thumb
    if art = "" then art = m.audioCover
    m.npArt.uri = art

    loadAudio(e.url)
    updateNowPlayingLabel()
end sub

' The player currently in charge of the music
function audioNode() as object
    if m.audioEngine = "node" then return m.audioPlayer
    return m.audioVideo
end function

sub loadAudio(url as string)
    engineName = "video"
    if m.audioAttempt = 1 then engineName = "node"

    playUrl = url
    fmt = ""
    if m.audioAttempt = 2 then
        sep = "?"
        if Instr(1, url, "?") > 0 then sep = "&"
        playUrl = url + sep + "as=mp3"
        fmt = "mp3"
    else
        fmt = audioFormatFor(url, engineName)
    end if

    m.audioVideo.control = "stop"
    m.audioPlayer.control = "stop"
    m.audioEngine = engineName

    content = CreateObject("roSGNode", "ContentNode")
    content.url = playUrl
    if fmt <> "" then content.streamFormat = fmt
    node = audioNode()
    node.content = content
    node.control = "play"

    ' The Roku doesn't always report an error when it's stuck, so give up on each attempt after a while
    m.audioWatchdog.control = "stop"
    if m.audioAttempt = 2 then
        m.audioWatchdog.duration = 90
    else
        m.audioWatchdog.duration = 8
    end if
    m.audioWatchdog.control = "start"
end sub

function audioFormatFor(url as string, engineName as string) as string
    ext = extOf(url)
    if ext = "mp3" then return "mp3"
    if ext = "m4a" then return "mp4"
    if engineName = "node" then
        if ext = "flac" then return "flac"
        if ext = "aac" then return "es.aac-adts"
    end if
    return ""   ' wav, ogg, etc: let the Roku work it out
end function

function audioNodeHandles(ext as string) as boolean
    return ext = "mp3" or ext = "flac" or ext = "m4a" or ext = "aac"
end function

' Move on to the next way of playing the current track
sub advanceAudio()
    m.audioWatchdog.control = "stop"
    if m.audioQueue.Count() = 0 then return
    e = m.audioQueue[m.audioIndex]

    nextAttempt = m.audioAttempt + 1
    if nextAttempt = 1 and not audioNodeHandles(extOf(e.url)) then nextAttempt = 2

    if nextAttempt <= 2 then
        m.audioAttempt = nextAttempt
        if nextAttempt = 2 then
            m.npState.text = "Converting to MP3..."
        else
            m.npState.text = "Trying another player..."
        end if
        loadAudio(e.url)
        return
    end if

    msg = audioNode().errorMsg
    if msg = invalid or Type(msg) <> "roString" then msg = ""
    m.npState.text = "Can't play this file. " + msg + " (installing ffmpeg on the PC lets the server convert it)"
end sub

sub onAudioWatchdog()
    if not m.audioActive or m.audioQueue.Count() = 0 then return
    state = audioNode().state
    if state = "playing" or state = "paused" then return

    if m.audioAttempt < 2 then
        advanceAudio()
    else
        m.npState.text = "Still waiting... (converting a big file? check the server window)"
    end if
end sub

' Both players report here; only the one currently in charge is listened to
sub onAudioVideoState(event as object)
    if m.audioEngine = "video" then handleAudioState(event.getData())
end sub

sub onAudioPlayerState(event as object)
    if m.audioEngine = "node" then handleAudioState(event.getData())
end sub

sub onAudioVideoPosition(event as object)
    if m.audioEngine = "video" then updateAudioProgress(event.getData())
end sub

sub onAudioPlayerPosition(event as object)
    if m.audioEngine = "node" then updateAudioProgress(event.getData())
end sub

sub handleAudioState(state as string)
    m.npState.text = stateLabel(state)
    if state = "playing" or state = "paused" then m.audioWatchdog.control = "stop"

    if state = "finished" then
        nextTrack()
    else if state = "error" then
        advanceAudio()
    end if
    updateNowPlayingLabel()
end sub

function stateLabel(state as string) as string
    if state = "playing" then return "Playing"
    if state = "paused" then return "Paused"
    if state = "buffering" then return "Buffering..."
    if state = "finished" then return "Finished"
    if state = "stopped" then return "Stopped"
    if state = "error" then return "Error"
    return ""
end function

sub updateAudioProgress(curPos as dynamic)
    dur = audioNode().duration
    if curPos = invalid then curPos = 0
    if dur = invalid then dur = 0
    if dur > 0 then
        w = Int(m.BAR_WIDTH * curPos / dur)
        if w < 1 then w = 1
        if w > m.BAR_WIDTH then w = m.BAR_WIDTH
        m.npFill.width = w
    end if
    m.npTime.text = fmtTime(curPos) + " / " + fmtTime(dur)
end sub

sub nextTrack()
    if m.audioIndex < m.audioQueue.Count() - 1 then
        m.audioIndex = m.audioIndex + 1
        playTrack()
    else
        stopAudio()
        m.npState.text = "Finished"
    end if
end sub

sub prevTrack()
    if m.audioIndex > 0 then m.audioIndex = m.audioIndex - 1
    playTrack()
end sub

sub togglePause()
    node = audioNode()
    if node.state = "playing" then
        node.control = "pause"
    else if node.state = "paused" then
        node.control = "resume"
    end if
end sub

sub stopAudio()
    m.audioWatchdog.control = "stop"
    m.audioVideo.control = "stop"
    m.audioPlayer.control = "stop"
    m.audioActive = false
    updateNowPlayingLabel()
end sub

sub showNowPlaying()
    m.npGroup.visible = true
    m.top.setFocus(true)
end sub

sub closeNowPlaying()
    m.npGroup.visible = false
    m.list.setFocus(true)
end sub

sub updateNowPlayingLabel()
    if m.audioActive and m.audioQueue.Count() > 0 then
        m.nowPlaying.text = "Now playing: " + m.audioQueue[m.audioIndex].title + "     (Play button: open player)"
    else
        m.nowPlaying.text = ""
    end if
end sub

function handleNowPlayingKey(key as string) as boolean
    if key = "back" then
        closeNowPlaying()
    else if key = "OK" or key = "play" then
        togglePause()
    else if key = "left" or key = "rewind" then
        prevTrack()
    else if key = "right" or key = "fastforward" then
        nextTrack()
    else if key = "options" then
        stopAudio()
        closeNowPlaying()
    else
        return false
    end if
    return true
end function

' ---------- images (gallery + slideshow) ----------
sub startImages(idx as integer)
    m.imageQueue = []
    m.imageIndex = 0
    for i = 0 to m.entries.Count() - 1
        e = m.entries[i]
        if e.kind = "image" then
            if i = idx then m.imageIndex = m.imageQueue.Count()
            m.imageQueue.Push(e)
        end if
    end for
    m.slideshow = false
    m.imageGroup.visible = true
    m.top.setFocus(true)
    showImageAt(m.imageIndex)
end sub

sub showImageAt(i as integer)
    n = m.imageQueue.Count()
    if n = 0 then return
    if i < 0 then i = n - 1
    if i >= n then i = 0
    m.imageIndex = i

    e = m.imageQueue[i]
    m.imagePoster.uri = e.url
    cap = itos(i + 1) + " / " + itos(n) + "    " + e.title
    if m.slideshow then cap = cap + "    [slideshow on]"
    m.imageCaption.text = cap
end sub

sub toggleSlideshow()
    m.slideshow = not m.slideshow
    if m.slideshow then
        m.slideTimer.control = "start"
    else
        m.slideTimer.control = "stop"
    end if
    showImageAt(m.imageIndex)
end sub

sub onSlideTick()
    if m.imageGroup.visible and m.slideshow then showImageAt(m.imageIndex + 1)
end sub

function handleImageKey(key as string) as boolean
    if key = "back" then
        closeViewer()
    else if key = "left" or key = "rewind" then
        showImageAt(m.imageIndex - 1)
    else if key = "right" or key = "fastforward" then
        showImageAt(m.imageIndex + 1)
    else if key = "OK" or key = "play" then
        toggleSlideshow()
    else
        return false
    end if
    return true
end function

' ---------- text ----------
sub showText(title as string, body as string)
    m.textTitle.text = title
    m.textArea.text = body
    m.textGroup.visible = true
    m.textArea.setFocus(true)
end sub

sub closeViewer()
    m.slideshow = false
    m.slideTimer.control = "stop"
    m.imageGroup.visible = false
    m.textGroup.visible = false
    m.imagePoster.uri = ""
    m.list.setFocus(true)
end sub

' ---------- server address dialog ----------
sub openServerDialog()
    dlg = CreateObject("roSGNode", "KeyboardDialog")
    dlg.title = "Server address"
    dlg.message = "IP[:port] or full URL, e.g. 192.168.1.50:8000"
    dlg.text = m.server
    dlg.buttons = ["Connect", "Cancel"]
    dlg.observeFieldScoped("buttonSelected", "onServerDialog")
    m.top.dialog = dlg
end sub

sub onServerDialog(event as object)
    idx = event.getData()
    dlg = m.top.dialog
    text = dlg.text
    dlg.close = true
    m.list.setFocus(true)

    if idx = 0 then
        url = normalizeServer(text)
        if url <> "" then
            m.server = url
            m.reg.Write("server", url)
            m.reg.Flush()
            m.stack = []
            m.currentUrl = ""
            navigateTo(url, "none")
        end if
    end if
end sub

function normalizeServer(t as string) as string
    t = t.Trim()
    if t = "" then return ""
    if LCase(Left(t, 7)) <> "http://" and LCase(Left(t, 8)) <> "https://" then t = "http://" + t
    p = Instr(1, t, "://")
    if Instr(p + 3, t, "/") = 0 then t = t + "/"
    return t
end function

' ---------- small helpers ----------
function itos(n as integer) as string
    return Str(n).Trim()
end function

function fmtTime(s as dynamic) as string
    if s = invalid then return "0:00"
    total = Int(s)
    mins = total \ 60
    secs = total mod 60
    secText = itos(secs)
    if secs < 10 then secText = "0" + secText
    return itos(mins) + ":" + secText
end function

function extOf(url as string) as string
    n = LCase(url)
    q = Instr(1, n, "?")
    if q > 0 then n = Left(n, q - 1)
    i = Len(n)
    while i > 0
        c = Mid(n, i, 1)
        if c = "." then return Mid(n, i + 1)
        if c = "/" then return ""
        i = i - 1
    end while
    return ""
end function

' ---------- remote keys ----------
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if m.video.visible then
        if key = "back" then
            closeVideo()
            return true
        end if
        return false
    end if

    if m.npGroup.visible then return handleNowPlayingKey(key)
    if m.imageGroup.visible then return handleImageKey(key)

    if m.textGroup.visible then
        if key = "back" then
            closeViewer()
            return true
        end if
        return false
    end if

    if key = "back" then
        if m.stack.Count() > 0 then
            prev = m.stack.Peek()
            navigateTo(prev.url, "pop")
            return true
        end if
        return false   ' at the top level: let Roku exit the app
    end if

    if key = "options" then
        openServerDialog()
        return true
    end if

    if key = "play" and m.audioActive then
        showNowPlaying()
        return true
    end if

    if key = "replay" and m.currentUrl <> "" then
        navigateTo(m.currentUrl, "refresh")
        return true
    end if

    return false
end function
